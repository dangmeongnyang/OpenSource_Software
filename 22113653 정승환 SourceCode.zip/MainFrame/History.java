package health;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Map;
import java.util.TreeMap;

public class History extends JDialog {
    private JTable table;
    private DefaultTableModel model;

    public History(JFrame parent) {
    	super(parent, "History", true);
        setSize(400, 300);
        setLocationRelativeTo(parent);

        model = new DefaultTableModel();
        model.addColumn("Date");
        model.addColumn("Calories");
        model.addColumn("Exercise");

        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
        loadData();
    }

    private void loadData() {
    	
        Map<String, Server.DailyData> sortedMap = new TreeMap<>(Server.dataMap);
        for (Map.Entry<String, Server.DailyData> entry : sortedMap.entrySet()) {
            String date = entry.getKey();
            Server.DailyData data = entry.getValue();
            model.addRow(new Object[]{date, data.getCalories(), data.getExercise()});
        }
    }
}